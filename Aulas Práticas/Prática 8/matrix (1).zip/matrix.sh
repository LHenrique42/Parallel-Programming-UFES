#$ -S /bin/sh

time ./matrix
